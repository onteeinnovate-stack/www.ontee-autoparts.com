-- Execute in Supabase SQL Editor. All write operations use server-only service role.
create extension if not exists pgcrypto;
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(), category text not null check(category in ('Shock Absorbers','Radiators','Brake System','Suspension Parts','Auto Hood','Auto Door','Auto Fender','Auto Tailgate')),
 name text not null, sku text, oem_number text, vehicle_make text, vehicle_model text, model_years text,
 description text, image_url text, spec_json jsonb not null default '{}'::jsonb,
 published boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.rfqs (
 id uuid primary key default gen_random_uuid(), buyer text not null, company text not null, email text not null,
 country text, whatsapp text, part text not null, reference text, qty text, port text, message text not null,
 status text not null default 'new' check(status in ('new','reviewing','quoted','closed')),
 email_status text not null default 'pending' check(email_status in ('pending','sent','failed')),
 created_at timestamptz not null default now()
);
alter table public.products enable row level security;
alter table public.rfqs enable row level security;
revoke all on public.products from anon,authenticated;
revoke all on public.rfqs from anon,authenticated;
grant select on public.products to anon,authenticated;
create policy "published products only" on public.products for select to anon,authenticated using (published=true);
-- No client-side policy grants access to RFQ records. Use the Supabase dashboard for initial admin operations.
create index if not exists products_category_idx on public.products(category) where published=true;
create index if not exists rfqs_created_idx on public.rfqs(created_at desc);
