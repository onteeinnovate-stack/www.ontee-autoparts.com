# Ontee Auto Parts Co., Ltd. — 正式官網部署套件（待設定）

## 現況
本套件包含可部署的靜態網站、Cloudflare Pages RFQ API、Supabase SQL 資料表與權限設定，以及 WINWIN O.E.C. Logo。**尚未購買網域、部署、設定 API 金鑰或測試真實寄信。** 目前前端產品為八類示範分類，不是經確認的 OEM 產品資料庫。沒有建立自訂管理員 UI；初期使用 Supabase Dashboard 管理產品與 RFQ。

## 網域及帳號（必須由 Ontee 擁有）
1. 查詢並註冊 `ontee-autoparts.com`；尚未確認可註冊。開啟 Cloudflare 帳號及 Pages 專案。
2. 開啟 Supabase 專案，於 SQL Editor 執行 `sql/schema.sql`。在 Supabase Dashboard 管理 `products` 與 `rfqs`。
3. 開啟 Resend 帳號，驗證 `ontee-autoparts.com` 的 DNS 記錄（包含寄信驗證）。
4. 在 Cloudflare Turnstile 建立 widget，加入 `ontee-autoparts.com` 的 hostname。
5. 將此資料夾以 Git 儲存庫連接到 Cloudflare Pages；專案根目錄即此資料夾，靜態輸出目錄為 `.`，Functions 位於 `functions/api/`。如部署平台要求 build 指令，可留空。
6. 在 Pages 專案的 Settings → Variables and Secrets 設定以下變數。API 金鑰一律使用 **Secret**，不可貼在前端程式或提交到 Git。

| 變數 | 類型 | 說明 |
|---|---|---|
| SUPABASE_URL | 變數 | Supabase 專案 URL |
| SUPABASE_SERVICE_ROLE_KEY | Secret | 只允許伺服器存取的密鑰 |
| RESEND_API_KEY | Secret | Resend 寄信 API 金鑰 |
| RFQ_FROM_EMAIL | 變數 | `Ontee RFQ <rfq@ontee-autoparts.com>`（驗證後才可使用） |
| TURNSTILE_SITE_KEY | 變數 | 公開的 Turnstile site key |
| TURNSTILE_SECRET_KEY | Secret | Turnstile server secret |

7. 將自訂網域與 `www` 轉址設定至 Cloudflare Pages，啟用 HTTPS。設定 SPF、DKIM、DMARC 並測試 Gmail 收件與垃圾郵件資料夾。
8. 使用海外測試信箱提交 RFQ，確認資料寫入 Supabase `rfqs`，且 Gmail `onteeinnovate@gmail.com` 收到通知。測試空欄位、非法分類、錯誤 Turnstile、重複提交與郵件 API 失敗。部署前配置 Cloudflare WAF / rate limiting、備份及資料保留政策。

## 後端設計
- `POST /api/rfq`：驗證欄位與 Turnstile → 寫入 `rfqs` → Resend 發信至 onteeinnovate@gmail.com → 記錄 email_status。
- `GET /api/config`：僅公開 Turnstile site key。
- DB 使用 RLS，`rfqs` 對匿名及一般登入使用者不開放讀寫，只有伺服器 Service Role 可操作。
- 寄送失敗時仍保存 RFQ，標記 `failed`，**需由管理員檢查並重送**；尚未實作自動重試排程或寄送佇列。
- 產品表 `products` 可由 Supabase Dashboard 編輯；公開端目前使用示範類別，**尚未串接 Supabase 產品讀取、上傳管理或自訂後台**。

## 上線前不可省略
- 加入隱私權政策（說明 RFQ 個資用途、保存期限與聯絡窗口），以及買主資料刪除流程。
- 實作 IP 速率限制、寄信失敗重試或人工告警、後台 MFA、監控與定期備份。
- 驗證品牌、產品圖片授權與產品規格；未核實的 OEM、價格、適配年份不得刊登。
- 進行真實端到端測試及手機瀏覽器測試。**此套件是部署起點，不代表已經完成生產驗收。**
