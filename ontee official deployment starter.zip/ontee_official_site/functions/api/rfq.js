const json = (body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
const clean=(v,max=300)=>typeof v==='string'?v.trim().slice(0,max):'';
const categories=new Set(['Shock Absorbers','Radiators','Brake System','Suspension Parts','Auto Hood','Auto Door','Auto Fender','Auto Tailgate']);
export async function onRequestPost({request,env}){
 if(!env.SUPABASE_URL||!env.SUPABASE_SERVICE_ROLE_KEY||!env.RESEND_API_KEY||!env.TURNSTILE_SECRET_KEY||!env.RFQ_FROM_EMAIL)return json({error:'Service not configured.'},503);
 const origin=request.headers.get('origin');if(origin&&new URL(origin).host!==new URL(request.url).host)return json({error:'Invalid origin.'},403);
 if(Number(request.headers.get('content-length')||0)>16000)return json({error:'Request too large.'},413);
 let input;try{input=await request.json()}catch{return json({error:'Invalid JSON.'},400)}
 if(!input||typeof input!=='object')return json({error:'Invalid data.'},400);
 if(input.website)return json({ok:true}); // honeypot
 const d={buyer:clean(input.buyer,120),company:clean(input.company,160),email:clean(input.email,200),country:clean(input.country,100),whatsapp:clean(input.whatsapp,70),part:clean(input.part,80),reference:clean(input.reference,160),qty:clean(input.qty,100),port:clean(input.port,150),message:clean(input.message,3000)};
 if(!d.buyer||!d.company||!/^\S+@\S+\.\S+$/.test(d.email)||!categories.has(d.part)||!d.message)return json({error:'Please complete the required fields.'},400);
 if(!input.consent)return json({error:'Please confirm consent to contact you about this inquiry.'},400);
 const token=clean(input.turnstileToken,3000);if(!token)return json({error:'Please complete verification.'},400);
 let verified;try{const r=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',body:new URLSearchParams({secret:env.TURNSTILE_SECRET_KEY,response:token,remoteip:request.headers.get('CF-Connecting-IP')||''})});verified=await r.json()}catch{return json({error:'Verification unavailable. Try again.'},503)}
 if(!verified.success)return json({error:'Verification failed. Please retry.'},400);
 const id=crypto.randomUUID();const record={id,...d,status:'new',email_status:'pending',created_at:new Date().toISOString()};
 const base=env.SUPABASE_URL.replace(/\/$/,'');
 const db=await fetch(base+'/rest/v1/rfqs',{method:'POST',headers:{'apikey':env.SUPABASE_SERVICE_ROLE_KEY,'Authorization':'Bearer '+env.SUPABASE_SERVICE_ROLE_KEY,'Content-Type':'application/json','Prefer':'return=minimal'},body:JSON.stringify(record)}).catch(()=>null);
 if(!db||!db.ok)return json({error:'Unable to save inquiry. Please try again.'},503);
 const lines=[['Inquiry ID',id],['Name',d.buyer],['Company',d.company],['Email',d.email],['Country',d.country],['WhatsApp',d.whatsapp],['Product Category',d.part],['Product / OEM Reference',d.reference],['Quantity',d.qty],['Destination Port',d.port],['Details',d.message]].map(([k,v])=>k+': '+(v||'Not provided')).join('\n');
 let sent=false;try{const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':id},body:JSON.stringify({from:env.RFQ_FROM_EMAIL,to:['onteeinnovate@gmail.com'],reply_to:d.email,subject:'New RFQ | '+d.part+' | '+d.company,text:lines})});sent=r.ok}catch{}
 await fetch(base+'/rest/v1/rfqs?id=eq.'+encodeURIComponent(id),{method:'PATCH',headers:{'apikey':env.SUPABASE_SERVICE_ROLE_KEY,'Authorization':'Bearer '+env.SUPABASE_SERVICE_ROLE_KEY,'Content-Type':'application/json'},body:JSON.stringify({email_status:sent?'sent':'failed'})}).catch(()=>{});
 return json({ok:true,id,notification:sent?'sent':'pending',message:sent?'Inquiry received.':'Inquiry saved; email notification pending.'},202);
}
export function onRequestGet(){return json({error:'Method not allowed.'},405)}
