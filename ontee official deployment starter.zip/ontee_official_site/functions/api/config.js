export function onRequestGet({env}) {return new Response(JSON.stringify({turnstileSiteKey:env.TURNSTILE_SITE_KEY||''}),{headers:{'content-type':'application/json','cache-control':'no-store'}})}
